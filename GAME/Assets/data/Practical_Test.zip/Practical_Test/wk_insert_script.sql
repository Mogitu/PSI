INSERT INTO `functie` (`functienaam`,`functieomschrijving`) VALUES ('Assistant referee','Grensrechter');
INSERT INTO `functie` (`functienaam`,`functieomschrijving`) VALUES ('FIFA delegate','Scheidsrechter begeleider');
INSERT INTO `functie` (`functienaam`,`functieomschrijving`) VALUES ('FIFA observer','Wedstrijdobservant');
INSERT INTO `functie` (`functienaam`,`functieomschrijving`) VALUES ('Fourth official','Reserve scheidsrechter');
INSERT INTO `functie` (`functienaam`,`functieomschrijving`) VALUES ('Referee','Wedstrijdleider');


INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('ALG','Algerije','Afrika','Vahid Halilhodzic');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('AUS','Australië','Oceanië','Ange Postecoglou');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('BEL','Belgie','Europa','Marc Wilmots');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('CHI','Chili','Zuid-Amerika','Jorge Sampaoli');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('KOR','Zuid-Korea','Azië','Hong Myung-Bo');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('NED','Nederland','Europa','Louis van Gaal');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('RUS','Rusland','Azië','Fabio Capello');
INSERT INTO `land` (`landcode`,`landnaam`,`werelddeel`,`bondscoach`) VALUES ('SPA','Spanje','Europa','Vicente del Bosque');

INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (1312,'Bjorn','Kuipers','','NED','Referee');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (1831,'Enrique','Osses','','CHI','Referee');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (2056,'Hakan','Anaz','','AUS','Assistant referee');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (2093,'Roberto','Fernandez','','SPA','Assistant referee');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (3969,'Jamal','Haimoudi','','ALG','Fourth official');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (4345,'Valentin','Ivanov','','RUS','FIFA observer');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (4907,'René','Temmink','','NED','FIFA observer');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (5665,'Mokhtar','Amalou','','ALG','FIFA delegate');
INSERT INTO `medewerker` (`medwnr`,`voornaam`,`achternaam`,`tussenvoegsel`,`landcode`,`functienaam`) VALUES (9999,'r',NULL,'f','NED','Referee');

INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (1672,'BEL','ALG',2,1);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (3827,'AUS','SPA',0,3);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (4931,'CHI','AUS',2,0);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (6411,'SPA','NED',1,5);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (7281,'RUS','BEL',0,1);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (7384,'KOR','BEL',0,1);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (7843,'NED','CHI',2,0);
INSERT INTO `wedstrijd` (`wedstrijdnr`,`thuisploeg`,`uitploeg`,`goalsVoor`,`goalsTegen`) VALUES (9821,'ALG','RUS',1,1);

INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (1672,1312);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (3827,1831);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (7281,1831);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (7843,2056);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (4931,3969);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (4931,4345);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (6411,4345);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (7384,4345);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (9821,4907);
INSERT INTO `inzetMedewerkers` (`wedstrijdnummer`,`medewerkernummer`) VALUES (6411,5665);



