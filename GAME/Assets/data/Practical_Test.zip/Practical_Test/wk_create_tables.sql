
CREATE TABLE `functie` (
  `functienaam` varchar(30) NOT NULL,
  `functieomschrijving` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`functienaam`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `land` (
  `landcode` varchar(12) NOT NULL,
  `landnaam` varchar(45) DEFAULT NULL,
  `werelddeel` varchar(45) DEFAULT NULL,
  `bondscoach` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`landcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `medewerker` (
  `medwnr` int(11) NOT NULL,
  `voornaam` varchar(45) DEFAULT NULL,
  `achternaam` varchar(45) DEFAULT NULL,
  `tussenvoegsel` varchar(45) DEFAULT NULL,
  `landcode` varchar(45) DEFAULT NULL,
  `functienaam` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`medwnr`),
  KEY `medfunc_idx` (`functienaam`),
  KEY `medland_idx` (`landcode`),
  CONSTRAINT `medfunc` FOREIGN KEY (`functienaam`) REFERENCES `functie` (`functienaam`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `medland` FOREIGN KEY (`landcode`) REFERENCES `land` (`landcode`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `wedstrijd` (
  `wedstrijdnr` int(11) NOT NULL,
  `thuisploeg` varchar(45) DEFAULT NULL,
  `uitploeg` varchar(45) DEFAULT NULL,
  `goalsVoor` int(11) DEFAULT NULL,
  `goalsTegen` int(11) DEFAULT NULL,
  PRIMARY KEY (`wedstrijdnr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `inzetMedewerkers` (
  `wedstrijdnummer` int(11) NOT NULL,
  `medewerkernummer` int(11) NOT NULL,
  PRIMARY KEY (`wedstrijdnummer`,`medewerkernummer`),
  KEY `fk_medewerkerInzet_idx` (`medewerkernummer`),
  CONSTRAINT `fk_medewerkerInzet` FOREIGN KEY (`medewerkernummer`) REFERENCES `medewerker` (`medwnr`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_wedstrijdInzet` FOREIGN KEY (`wedstrijdnummer`) REFERENCES `wedstrijd2` (`wedstrijdnr`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
